<?php
error_reporting(0);
$token = json_decode(file_get_contents('admin.json'),true)['info']['token'];
$id = json_decode(file_get_contents('admin.json'),true)['info']['id'];
include 'index.php';
$admin = json_decode(file_get_contents('admin.json'),true);
$checked = 0;
$hit = 0;
$bad = 0;
$error = 0;
$len = file_get_contents('length');
$ses = file_get_contents('session');
$edit = bot('sendMessage',[
'chat_id'=>$id,
'text'=>"
Done Started Checking 
Length : $len
Session : 
$ses
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Checked : $checked ",'callback_data'=>'1']],
[['text'=>"In : $user",'callback_data'=>'2']],
[['text'=>"Hit : $hit",'callback_data'=>'3']],
[['text'=>"Bad : $bad",'callback_data'=>'4']],
[['text'=>"Error : $error",'callback_data'=>'5']],
]
])
]);
$len1 = file_get_contents('length');
$len = $len1 - 1;
$session = file_get_contents('session');
while(true){
$user1 = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz0123456789'),1,$len);
$user = ".$user1";
$check = check($user,$session);
if($check == 'true'){
$hit += 1;
$checked += 1;
bot('editMessageReplyMarkup',[
'chat_id'=>$id,
'message_id'=>$edit->result->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Checked : $checked ",'callback_data'=>'1']],
[['text'=>"In : $user",'callback_data'=>'2']],
[['text'=>"Hit : $hit",'callback_data'=>'3']],
[['text'=>"Bad : $bad",'callback_data'=>'4']],
[['text'=>"Error : $error",'callback_data'=>'5']],
]
])
]);
bot('sendMessage',[
'chat_id'=>$id,
'text'=>"
New User 🧟
User : $user
Credit : @C_Y_L
",
]);
}elseif($check == 'false'){
$bad += 1;
$checked += 1;
bot('editMessageReplyMarkup',[
'chat_id'=>$id,
'message_id'=>$edit->result->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Checked : $checked ",'callback_data'=>'1']],
[['text'=>"In : $user",'callback_data'=>'2']],
[['text'=>"Hit : $hit",'callback_data'=>'3']],
[['text'=>"Bad : $bad",'callback_data'=>'4']],
[['text'=>"Error : $error",'callback_data'=>'5']],
]
])
]);
} else {
$error += 1;
$checked += 1;
bot('editMessageReplyMarkup',[
'chat_id'=>$id,
'message_id'=>$edit->result->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Checked : $checked ",'callback_data'=>'1']],
[['text'=>"In : $user",'callback_data'=>'2']],
[['text'=>"Hit : $hit",'callback_data'=>'3']],
[['text'=>"Bad : $bad",'callback_data'=>'4']],
[['text'=>"Error : $error",'callback_data'=>'5']],
]
])
]);
}
}
?>
