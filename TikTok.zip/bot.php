<?php
error_reporting(0);
if(!file_exists('admin.json')){
$token = readline('Enter Token : ');
$id = readline('Enter Id : ');
file_put_contents("start","Stopped");
$save['info'] = [
'token'=>$token,
'id'=>$id
];
file_put_contents('admin.json',json_encode($save),64|128|256);
}
function save($array){
file_put_contents('admin.json',json_encode($array),64|128|256);
}
$token = json_decode(file_get_contents('admin.json'),true)['info']['token'];
$id = json_decode(file_get_contents('admin.json'),true)['info']['id'];
include 'index.php';
if($id == ""){
echo "Error Id";
}
try {
 $callback = function ($update, $bot) {
  global $id;
  if($update != null){
   if(isset($update->message)){
    $message = $update->message;
    $chat_id = $message->chat->id;   
    $name = $message->from->first_name;
    $message_id = $message->message_id;
    $text = $message->text;
$admin = json_decode(file_get_contents('admin.json'),true);
if($text == '/start' && $chat_id == $admin['info']['id']){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*
Tik Tok Checker (:
Credit : @C_Y_L
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Start .','callback_data'=>'start'],['text'=>'- Stop .','callback_data'=>'stop']],
[['text'=>'- Status .','callback_data'=>'status']],
]
])
]);
}
if($text != "/start" && file_get_contents("mode") == "session" && $chat_id == $admin['info']['id']){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*
Now You Have To Choose Lenght If The User (:
Session : $text
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- 4 .','callback_data'=>'co#4'],['text'=>'- 5 .','callback_data'=>'co#5']],
[['text'=>'- Go Back .','callback_data'=>'back']],
]
])
]);
file_put_contents("session",$text);
unlink("mode");
}
}
if(isset($update->callback_query)) {
    $chat_id1 = $update->callback_query->message->chat->id;
    $mid = $update->callback_query->message->message_id;
    $data = $update->callback_query->data;
    $message = $update->message;
    $chat_id = $message->chat->id;
    $text = $message->text;
    $name = $message->from->first_name;
if($data == 'start'){
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
Now Please Send Me Your Session Id 
TikTok Ofc :)
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Go Back .','callback_data'=>'back']],
]
])
]);
file_put_contents("mode","session");
}
$ex = explode("#",$data);
if($ex['0'] == "co"){
$se = $ex['1'];
$ses = file_get_contents("session");
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
Done Set Session : 
$ses
And Length : $se
Do You Want To Start ? :)
*",  
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Start .','callback_data'=>'startt'],['text'=>'- Go Back .','callback_data'=>'back']],
]
])
]);
file_put_contents("length",$se);
}
if($data == "startt"){
bot('deleteMessage',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
]);
system("screen -dmS $chat_id1 php tik.php");
file_put_contents("start","Running");
}
if($data == "stop"){
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
Done Stopped The Bot ):
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Go Back .','callback_data'=>'back']],
]
])
]);
system("screen -S $chat_id1 -X kill");
file_put_contents("start","Stopped");
}
if($data == "back"){
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
Tik Tok Checker (:
Credit : @C_Y_L
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Start .','callback_data'=>'start'],['text'=>'- Stop .','callback_data'=>'stop']],
[['text'=>'- Status .','callback_data'=>'status']],
]
])
]);
unlink("mode");
unlink("session");
unlink("length");
}
if($data == 'status'){
$status = file_get_contents('start');
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
Stauts : $status (:
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Go Back .','callback_data'=>'back']],
]
])
]);


}
}
      }
    };
         $bot = new EzTG(array('throw_telegram_errors'=>true,'token' => $token, 'callback' => $callback));
  }
    catch(Exception $e){
 echo $e->getMessage().PHP_EOL;
 sleep(1);
}
